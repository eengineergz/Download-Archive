Goto : 
XML config
[http://chirpy.codeplex.com/wikipage?title=XML%20Config](http://chirpy.codeplex.com/wikipage?title=XML%20Config)
Version 2
[http://www.weirdlover.com/2011/03/03/chirpy-v2/](http://www.weirdlover.com/2011/03/03/chirpy-v2/)
Version 1.0.0.5
[http://www.weirdlover.com/2010/09/07/chirpy-to-the-xxxtreme-v1-0-0-5-da-kine-release/](http://www.weirdlover.com/2010/09/07/chirpy-to-the-xxxtreme-v1-0-0-5-da-kine-release/)
Version 1.0.0.4
[http://www.weirdlover.com/2010/07/18/chirpy-attains-godlike-abilities-in-version-1-0-0-4/](http://www.weirdlover.com/2010/07/18/chirpy-attains-godlike-abilities-in-version-1-0-0-4/)